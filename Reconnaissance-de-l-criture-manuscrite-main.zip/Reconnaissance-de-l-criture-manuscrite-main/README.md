# Reconnaissance de l'écriture manuscrite
réalisation d' un système de reconnaissance de l'écriture manuscrite et comment  la transformer en écriture machine dans un PDF.
